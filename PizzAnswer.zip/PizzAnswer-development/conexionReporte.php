<?php
	/** 
	 * Verifica que haya conexión con la base datos y si no manda un error de conexión
	 * @var $link ruta de donde esta la base datos
	 * @var $usuario usuario root o otro de la bd
	 * @var $pass contraseña de la base datos
	 * @var $bd nombre de la base datos que queremos consultar
	 * @var $mysql MYSQL instancia para crear una nueva conexión
	*/
	/*
	$link = 'sql3.freesqldatabase.com:3306/; dbname=sql3418606; charset=utf8';
	$usuario = 'sql3418606';
	$pass = 'FcqWkvTndP';
	$bd = 'sql3418606';
	$mysqli = new mysqli($link,$usuario,$pass,$bd);
	if($mysqli->connect_error){
		die('Error en la conexion' . $mysqli->connect_error);	
	}
	*/

	//Conexión para que funcione en el webhost

$servername = "localhost";
$username = "id16915195_admin";
$password = "PizzaPizza123_";
$database = "id16915195_pizzanswer";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    } catch(PDOException $e) {    
    echo "Connection failed: " . $e->getMessage();
    die();
}

?>