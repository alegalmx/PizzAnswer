/*
*
* PHP: consulta.php 
* BASE DE DATOS: PizzAnswer
* VERSION: 1.0
* DESCRIPCION: Conexion de PHP con la BD para la generación de Generar Reporte
*
*/
<?php
		class Conexion{
			/** 
			*   Declaración de variables y su tipo de dato
			*
			*	@access public
			*   @var $ruta string
			*   @var $usuario string
			*   @var $contraseña string
			*   @var $baseDatos string
			*
			*/
			var $ruta;
			var $usuario;
			var $contrasena;
			var $baseDatos;
			/**
			* Verifica la función si existe conexión con los parametros a la base datos PizzAnswer
			*
			* @param string $ruta dirección de la base datos
			* @param string $usuario usuario definido de la bd
			* @param string $contrasena contraseña definida para la bd
			* @param string $baseDatos nombre de la base datos
			*
			*/
			function Conexion(){
				$this->ruta       ="mysql:host=sql3.freesqldatabase.com:3306/; dbname=sql3418606; charset=utf8"; //
				$this->usuario    ="sql3418606"; //usuario que tengas definido
				$this->contrasena ="FcqWkvTndP"; //contraseña que tengas definidad
				$this->baseDatos  ="sql3418606"; //base de datos personas, si quieres utilizar otra base de datos solamente cambiala
			}// Conexion
			/** 
			* Verifica que los datos ingresados desde el php conexionReporte.php den conexión con la bd 
			*
			* @param string $ruta dirección de la base datos
			* @param string $usuario usuario definido de la bd
			* @param string $contrasena contraseña definida para la bd
			* @param string $baseDatos nombre de la base datos
			* @param string $enlace link que junto a todas las variables para la conexion
			*/
			function conectarse(){
				//------------------------TIPO DE CONEXION 2 - RECOMENDADA---------------------------------------------
				$enlace = mysqli_connect($this->ruta, $this->usuario, $this->contrasena, $this->baseDatos);
				if($enlace){
					echo "Conexion exitosa";	//si la conexion fue exitosa nos muestra este mensaje como prueba, despues lo puedes poner comentarios de nuevo: //
				}else{
					die('Error de Conexión (' . mysqli_connect_errno() . ') '.mysqli_connect_error());
				}// $enlace
				return($enlace);
				// mysqli_close($enlace); //cierra la conexion a nuestra base de datos, un ounto de seguridad importante.
			} // conectarse
		} // Clase conexión

?>