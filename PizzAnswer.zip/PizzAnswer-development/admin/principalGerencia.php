<?php

/**
 *
 * PHP: principalGerencia.php
 * BASE DE DATOS: PizzAnswer
 * VERSION: 1.0
 * DESCRIPCION: Interfaz principal de la gerencia de la Pizzeria
 *
 */

include_once '..\conexion.php';
session_start();
$sql_leer = 'select A.nombreArea as "Area", (SUM(D.idCarita) / COUNT(R.respuesta)) as "Promedio" from areas A inner join pregunta P on (P.idAreas = A.idAreas) inner join respuestaencuesta R on (P.IdPregunta = R.IdPregunta) inner join datosCaritas D on (D.nombreCarita = R.respuesta) group by A.nombreArea';

$gsent = $pdo->prepare($sql_leer);
$gsent->execute();

$resultado = $gsent->fetchAll();

// if (!isset($_SESSION['user_id'])) {
//     header('Location: index.php');
//     exit;
// } else {
//     // Show users the page!
// }


?>

<!-- Creamos nuestro HTML -->
<html lang="es">

<head>
  <!-- Establecemos la compatabilidad de exploradores   -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Hacemos referencia a las hojas de estilos creadas y de Boostrap  -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel='stylesheet' type="text/css" href="../estiloa.css">
  <link rel='stylesheet' type="text/css" href="principalC.css">
  <!-- Le colocamos un titulo a nuestra pagina   -->
  <title>Principal Gerente</title>
</head>

<body>
  <!-- Llamamos un script de Boostrap para la creación de los botones
  -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
  <header>
    <!-- Establecemos un menu de la pizzeria   Inicio, Promociones, Encuesta, Cupones   -->
    <nav class="menuPizza">
      <img src="../images/logoNegro.PNG" class="logoP">
      <label class="logoPizza">PizzAnswer/Gerencia</label>
      <ul class="menupizza_item">
        <!-- Generamos las listas  -->
        <li><a href="principalGerencia.php">Inicio</a></li>
        <li><a href="verPromo.php">Promociones</a></li>
        <li><a href="verEncuesta.php">Encuesta</a></li>
        <li><a href="cuponAdmin.php">Cupones</a></li>
      </ul>
    </nav>
  </header> <!-- Aqui termina el header   -->
  <!-- Colocamos una imagen y los parrafos correspondientes    -->
  <img src="../images/pizzGerent.PNG" class="logoGerentP">
  <p class="tit1">¡Buenas tardes!</p>
  <p class="tit2">Esta semana la</p>
  <p class="tit3">pizzeria se siente:</p>
  <!-- Colocamos una imagen y los contenedores correspondientes    -->
  <div class="contenedorResumen">
    <?php foreach ($resultado as $dato) : ?>
      <?php if ($dato['Promedio'] >= 1.5) : ?>
        <div class="contenedorCaritas">
          <img src="../images/happyface.png" class="carita">
          <span><?php echo $dato['Area'] ?></span>
        </div>
      <?php elseif ($dato['Promedio'] >= 0.5 && $dato['Promedio'] < 1.5) : ?>
        <div class="contenedorCaritas">
          <img src="../images/happybored.png" class="carita">
          <span><?php echo $dato['Area'] ?></span>
        </div>
      <?php else : ?>
        <div class="contenedorCaritas">
          <img src="../images/happysad.png" class="carita">
          <span><?php echo $dato['Area'] ?></span>
        </div>
      <?php endif; ?>
    <?php endforeach ?>
  </div>

  <!-- Creamos botones y hacemos referencia a otros .php   -->
  <a href="cuponAdmin.php" class="bot1">
    <div>Cupones</div>
  </a>
  <a href="verPromo.php" class="bot2">
    <div>Promociones</div>
  </a>
  <a href="verEncuesta.php" class="bot3">
    <div>Encuesta</div>
  </a>
  <p class="reporte">¡Reporte mensual listo!</p>
  <a href="generarReporte.php" class="bot4">
    <div>Generar Reporte</div>
  </a>
</body>

</html>