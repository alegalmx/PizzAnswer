<?php

/**
*
* PHP Relacionados: conexion.php
* BASE DE DATOS: PizzAnswer -> pregunta
* VERSION: 1.0
* DESCRIPCION: Este archivo contiene la encuesta para que sea supervisada por el gerente
* 
*
*/

include_once '../conexion.php';

/**
 * SQL a ejecutar
 * @access public
 * @var string
 */

$sql_leer = 'SELECT * FROM pregunta WHERE enEncuesta = 1';

/**
 * Query SQL anterior preparado para ejecutarse usando el pdo
 * @access public
 * @var object
 * 
 */

$gsent = $pdo->prepare($sql_leer);
$gsent->execute();

$resultado = $gsent->fetchAll();

?>

    <html lang="es">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel='stylesheet' type="text/css" href="../estiloa.css">
        <link rel='stylesheet' type="text/css" href="verEncuesta.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <title>Encuesta | PizzAnswer</title>
    </head>

    <body>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
        <header>
            <nav class="menuPizza">
                <img src="../images/logoNegro.PNG" class="logoP">
                <label class="logoPizza">PizzAnswer</label>
                <ul class="menupizza_item">
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="verPromo.php">Promociones</a></li>
                    <li><a href="verEncuesta.php">Encuesta</a></li>
                </ul>
            </nav>
        </header>
        <div class="titulo">Visualizar Encuesta</div>
        <div class="encuesta">
            <div class="encuesta__preguntas-gen">
                <div id="pregunta__nombre" name="encuesta__preguntas-gen-nombre">
                    <span class="pregunta">1.- Ingrese su nombre:</span><br>
                    <input type="text" name="campo-nombre" class="pregunta__input">
                </div>
                <div id="pregunta__tel" name="encuesta__preguntas-gen-tel">
                    <span class="pregunta">2.- Ingrese su teléfono:</span><br>
                    <input type="tel" name="campo-tel" class="pregunta__input">
                </div>
            </div>
            <div class="encuesta__preguntas">
                <?php $i = 3 ?>
                <?php foreach ($resultado as $dato) : ?>
                <?php if ($dato['tipoPregunta'] == 1) : ?>
                <?php $pregunta = $dato['pregunta'] ?>
                <div class="encuesta__preguntas-db">
                    <span class="pregunta" name="pregunta-<?php echo $i?>"><?php echo strval($i) . '.- ' . $pregunta ?></span><br>
                    <div class="encuesta__respuesta-caras">
                        <label>
                            <input class="radio__res" type="radio" name="cara<?php echo $i ?>" value="0">
                            <?php  $pathToSVG = "../images/encuesta/excelente.svg";
                            $content    = file_get_contents($pathToSVG);?>
                            <svg class="caras__svg"><?php echo $content;?></svg><br>
                            <b class="caras__respuesta">Excelente</b>
                        </label>
                        <label>
                            <input class="radio__res" type="radio" name="cara<?php echo $i ?>" value="1">
                            <?php  $pathToSVG = "../images/encuesta/regular.svg";
                            $content    = file_get_contents($pathToSVG);?>
                            <svg class="caras__svg"><?php echo $content;?></svg><br>
                            <b class="caras__respuesta">Regular</b>
                        </label>
                        <label>
                            <input class="radio__res" type="radio" name="cara<?php echo $i ?>" value="2">
                            <?php  $pathToSVG = "../images/encuesta/mala.svg";
                            $content    = file_get_contents($pathToSVG);?>
                            <svg class="caras__svg" ><?php echo $content;?></svg><br>
                            <b class="caras__respuesta">Mala</b>
                        </label>
                    </div>
                </div>
                <?php elseif ($dato['tipoPregunta'] == 2) : ?>
                <?php $pregunta = $dato['pregunta'] ?>
                <div class="encuesta__preguntas-db">
                    <span class="pregunta" name="pregunta-<?php echo $i?>"><?php echo strval($i) . '.- ' . $pregunta ?></span><br>
                    <div class="encuesta__respuesta-texto">
                        <textarea class="text__res" name="texto<?php echo $i ?>" cols=50 rows=4></textarea>
                    </div>
                <?php endif; ?>
                <?php $i++ ?>
                <?php endforeach ?>
                </div>
                <div class="contenedorbotones">
                    <a href="addPregunta.php"><button type="#" class="botones">Agregar Pregunta</button></a>
                    <a href="delPregunta.php"><button type="#" class="botones">Eliminar Pregunta</button></a>
                    <a href="index.php"><button type="#" class="botones">Regresar</button></a>
                </div>
    </body>

    </html>