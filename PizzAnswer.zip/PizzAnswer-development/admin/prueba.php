<?php
   require '../conexionReporte.php';
   $sql = "SELECT r.numeroDeEncuesta  AS 'NumEncuesta', a.nombreArea AS 'Areas', r.respuesta AS 'Respuesta',  
   c.nombreCliente AS 'NombreCliente', c.telefonoCliente AS 'Telefono', r.fecha as 'FechaEncuesta'
   FROM respuestaencuesta r INNER join pregunta p ON (p.idPregunta = r.idPregunta) 
   inner join cliente c on (c.idCliente = r.idCliente) INNER JOIN areas a ON (a.idAreas = p.idAreas) order by r.id";
   $resultado = $mysqli -> query($sql);
   while($row=mysqli_fetch_assoc($resultado)){
      echo $row["Respuesta"];
   }
   mysqli_free_result($resultado);  
   mysqli_close($mysqli);?> 
?>