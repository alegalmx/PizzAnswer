/**
*
* PHP: addpregunta.php
* BASE DE DATOS: PizzAnswer -> pregunta
* VERSION: 1.0
* DESCRIPCION: Este codigo contiene lo necesario para agregar una pregunta.
*
*/

<?php
// Conexion a nuestra BD
include_once '..\conexion.php';

/**
   * SQL a ejecutar
   * @access public
   * @var object
*/
$sql_leer = 'SELECT * FROM pregunta';
/**
    * SQL necesario para preparar nuestra sentencia SQL
    * @access public
    * @var object
*/
$gsent = $pdo->prepare($sql_leer);
/**
   * Array de tipo string que nos otorgará todos los registros que la consulta generó
   * @access public
   * @var object
*/
$gsent->execute();
$resultado = $gsent->fetchAll();

/**
 * Este if será llamado solo cuando se haya presionado al botón de "aceptar", lo que hará será ejecutar las indicaciones que se le indican.
*/
if($_POST){
    /** 
            *   Declaración de variables y su tipo de dato
            *
            *   @access public
            *   @var $area int
            *   @var $tipo int
            *   @var $pregunta string
    */
    $area = $_POST['area'];
    $tipo = $_POST['tipo'];
    $pregunta = $_POST['pregunta'];
    /**
   * SQL a ejecutar
   * @access public
   * @var object
   */
    $sql_agregar = 'INSERT INTO pregunta(idAreas, tipoPregunta, pregunta) VALUES (?, ?, ?)';
    /**
     * SQL necesario para preparar nuestra sentencia SQL
     * @access public
     * @var object
     */
    $sentencia_agregar = $pdo->prepare($sql_agregar);
    /**
     * SQL necesario para ejecutar una insercion
     * @access public
     */
    $sentencia_agregar->execute(array($area, $tipo, $pregunta));
}
?>

<!-- Creacion de nuestro HTML -->
<html lang="es">
<head>
    <!-- Las siguientes instrucciones garantiza la compatibilidad entre navegadores -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- La siguiente instruccion es la hoja de estilos del header -->
    <link rel='stylesheet' type="text/css" href="../estiloa.css">
    <!-- La siguiente instruccion es la hora de estilos de la interfaz -->
    <link rel='stylesheet' type="text/css" href="addPreguntaR.css">
</head>
    <!-- La siguiente instruccion es el nombre de nuestra pestaña -->
    <title>Gerencia | Agregar pregunta</title>
<body>
    <header>
        <nav class = "menuPizza">
            <!-- La siguiente instruccion obtiene el logo de nuestro header desde la carpeta images -->
            <img src="../images/logoNegro.PNG" class="logoP">
            <!-- La siguiente instruccion es el titulo del header -->
            <label class="logoPizza">PizzAnswer/Gerencia</label>
            <!-- La siguiente instruccion sirve para realizar los elementos del header -->
            <ul class="menupizza_item">
                <!-- El siguiente elemento sirve para redirigirse a la interfaz principalGerencia.php -->
                <li><a href="principalGerencia.php">Inicio</a></li>
                <!-- El siguiente elemento sirve para redirigirse a la interfaz verPromo.php -->
                <li><a href="verPromo.php">Promociones</a></li>
                <!-- El siguiente elemento sirve para redirigirse a la interfaz verEncuesta.php -->
                <li><a href="verEncuesta.php">Encuesta</a></li>
            </ul>
        </nav>
    </header>
    <!-- En la siguiente instruccion tenemos nuestro titulo de la interfaz -->
    <p class="pt1">Agregar Pregunta</p>
    <!-- En la siguiente instruccion tenemos una clase contenedor la cual es utilizada para mover el formulario completo -->
    <div class="contenedor">
        <!-- En la siguiente instruccion tenemos una clase form la cual incluira todos nuestros componentes del formulario -->
        <div class="form">
            <!-- La siguiente instruccion sirve para indicar que vamos a crear un formulario y prepararlo para enviar los datos -->
            <form action="#" method="POST">
                <!-- La siguiente instruccion sirve para agregar combobox para elegir el area -->
                <p class="textos">Área:<select name="area" class="elementos"></p>
                    <option selected disabled="0">Seleccione una opción</option>
                    <option value="1">Levantamiento de pedidos</option>
                    <option value="2">Servicio a domicilio</option>
                    <option value="3">Cocina</option>
                </select>
                <br>
                <br>
                <!-- La siguiente instruccion sirve para agregar combobox para elegir el tipo de pregunta -->
                <p class="textos">Tipo:<select name="tipo" class="elementos"></p>
                    <option selected disabled="0">Seleccione una opción</option>
                    <option value="1">Pregunta de satisfacción</option>
                    <option value="2">Pregunta abierta</option>
                </select>
                <br>
                <br>
                <!-- La siguiente instruccion sirve para agregar un campo de texto el cual sirve para indicar la pregunta que se quiere agregar -->
                <p class="textos">Pregunta:<input type="text" name="pregunta" class="elementol" placeholder="Escriba su pregunta aquí..." required></p>
                <br>
                <br>
                <br>
                <!-- La siguiente instruccion sirve para agregar un boton el cual funcionara para enviar los datos a la BD -->
                <input type="submit" name="btnAceptar" class="boton1" value="Aceptar">
            </form>
            <!-- La siguiente instruccion sirve para agregar un boton el cual redirigira a la interfaz verEncuesta.php -->
            <a href="verEncuesta.php"><button type="submit" id="btn_regresar" class="boton2">Regresar</button></a>
        </div>
    </div>
</body>
</html