<?php 
/**
*
* PHP Relacionados: delPromo.php, function.php
* BASE DE DATOS: PizzAnswer -> promocion
* VERSION: 1.0
* DESCRIPCION: Esta parte del codigo hará un llamado al archivo function.php al cual le enviará la información necesaria para eliminar
* una promoción de la base de datos
*
*/
include("function.php");

/**
 * id de la promocion a eliminar
 * @access publico
 * @var string id
 */
$id = $_GET['id'];

/**
* Elimina el registro de la promocion deseada para que este mismo deje de aparecer en la encuesta.
* Se envia el nombre de la tabla, el campo y el valor a comparar para la función delete del archivo function.php
*/
delete('promocion','idPromocion',$id);

/**
* Actualiza la pagina actual para regresarnos nuevamente a delPromo.php que es aquella que llamó a esta función
*/
header("location:../delPromo.php");
?>