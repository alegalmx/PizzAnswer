<?php
/**
*
* PHP Relacionados: borrarPregunta.php, borrarPromo.php
* BASE DE DATOS: PizzAnswer -> todo
* VERSION: 1.0
* DESCRIPCION: Este archivo contiene las funciones necesarias para eliminar, actualizar y seleccionar información de cualquier
* tabla que tengamos en nuestra base de datos
*
*/

/**
* Ejecuta un query en la BDD
*
* @return mysqli_result
* resultado si la ejecución de la conexión fue correcta
* @param string $query query sql a ejecutar dentro de nuestra BDD
*/
function db_query($query) {
    $connection = mysqli_connect("sql3.freesqldatabase.com:3306/","sql3418606","FcqWkvTndP","sql3418606");
    $result = mysqli_query($connection,$query);

    return $result;
}

/**
* Elimina el registro con valor X de la tabla Y de nuestra BDD
*
* @return mysqli_result resultado si la ejecución del borrado fue correcta
* @param string $tblname Nombre de la tabla de donde queremos eliminar el registro
* @param string $field_id Nombre del campo a comparar para eliminar
* @param string $id Valor del campo que queremos eliminar
*/
function delete($tblname,$field_id,$id){ //Funcion para borrar registros

	$sql = "delete from ".$tblname." where ".$field_id."=".$id."";
	
	return db_query($sql);
}

/**
* Actualiza un registro de la tabla deseada
*
* @return mysqli_result resultado si la ejecución de la actualización fue correcta
* @param string $tblname Nombre de la tabla a actualizar
* @param string $field_id Nombre del campo a comparar para actualizar
* @param string $id Valor del campo que queremos eliminar
*/
function update($tblname,$field_id,$id){ //Funcion para borrar registros

	$sql = "update ".$tblname." set enEncuesta = 0 where ".$field_id."=".$id."";
	
	return db_query($sql);
}

/**
* Hace un select del registro deseado dentro de nuestra BDD
*
* @return string resultado si la ejecución de la consulta fue correcta
* @param string $tblname Nombre de la tabla de donde haremos la consulta
* @param string $field_name Campo para comparar y pedir la consulta
* @param string $id Valor del campo de los registros que deseamos consultar
*/
function select_id($tblname,$field_name,$field_id){
	$sql = "Select * from ".$tblname." where ".$field_name." = ".$field_id."";
	$db=db_query($sql);
	$GLOBALS['row'] = mysqli_fetch_object($db);

	return $sql;
}
?>