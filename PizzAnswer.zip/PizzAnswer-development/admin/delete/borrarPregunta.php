<?php 
/**
*
* PHP Relacionados: delPregunta.php, function.php
* BASE DE DATOS: PizzAnswer -> pregunta
* VERSION: 1.0
* DESCRIPCION: Esta parte del codigo hará un llamado al archivo function.php al cual le enviará la información necesaria para eliminar
* una pregunta directamente de la base de datos
*
*/
include("function.php");

/**
 * id de la pregunta a eliminar
 * @access publico
 * @var string id
 */
$id = $_GET['id'];

/**
* Actualiza el registro de la pregunta deseada para que este mismo deje de aparecer en la encuesta.
* Se envia el nombre de la tabla, el campo y el valor a comparar para la función update del archivo function.php
*/
update('pregunta','idPregunta',$id);

/**
* Actualiza la pagina actual para regresarnos nuevamente a delPregunta.php que es aquella que llamó a esta función
*/
header("location:../delPregunta.php");
?>