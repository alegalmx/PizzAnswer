<?php
   require('../librerias/PHPExcel/Classes/PHPExcel.php');
   require '../conexionReporte.php';
   //------------- Realizamos la consulta -------------------------------------!>
   $sql = "SELECT r.numeroDeEncuesta  AS 'NumEncuesta', a.nombreArea AS 'Areas', r.respuesta AS 'Respuesta',  
   c.nombreCliente AS 'NombreCliente', c.telefonoCliente AS 'Telefono', r.fecha as 'FechaEncuesta'
   FROM respuestaencuesta r INNER join pregunta p ON (p.idPregunta = r.idPregunta)  
   inner join cliente c on (c.idCliente = r.idCliente) INNER JOIN areas a ON (a.idAreas = p.idAreas) order by r.id";
   //------------- Guardamos el resultado y le decimos la fila para imprimir -------------------------------------!>
   $resultado = $mysqli -> query($sql);
   $fila = 7;
   $objPHPExcel = new PHPExcel();
   //------------- Colocas la ubicacion del logo y especificamos sus coordenadas -------------------------------------!>
   $gdImage = imagecreatefrompng('../images/logo.png');//Logotipo
   $objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
	$objDrawing->setName('Logotipo');
	$objDrawing->setDescription('Logotipo');
	$objDrawing->setImageResource($gdImage);
	$objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_PNG);
	$objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
	$objDrawing->setHeight(100);
	$objDrawing->setCoordinates('A1');
	$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
   $objPHPExcel->setActiveSheetIndex(0);
   //------------- Le damos el estitlo al titulo del reporte generado en Excel -------------------------------------!>
   $estiloTituloReporte = array(
      'font' => array(
     'name'      => 'Arial',
     'bold'      => true,
     'italic'    => false,
     'strike'    => false,
     'size' =>10
      ),
      'fill' => array(
     'type'  => PHPExcel_Style_Fill::FILL_SOLID
     ),
      'borders' => array(
     'allborders' => array(
     'style' => PHPExcel_Style_Border::BORDER_NONE
     )
      ),
      'alignment' => array(
     'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
     'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
      )
     );
     //------------- Le damos estilo a las columnas generadas del reporte de Excel -------------------------------------!>
     $estiloTituloColumnas = array(
      'font' => array(
     'name'  => 'Arial',
     'bold'  => true,
     'size' =>15,
     'color' => array(
     'rgb' => 'FFFFFF'
     )
      ),
      'fill' => array(
     'type' => PHPExcel_Style_Fill::FILL_SOLID,
     'color' => array('rgb' => 'EA6969')
      ),
      'borders' => array(
     'allborders' => array(
     'style' => PHPExcel_Style_Border::BORDER_THIN
     )
      ),
      'alignment' =>  array(
     'horizontal'=> PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
     'vertical'  => PHPExcel_Style_Alignment::VERTICAL_CENTER
      )
     );
     //------------- Hacemos una instancia de la clase PHPExcelStyle y le damos atributos al estilo de la información -------------------------------------!>
     $estiloInformacion = new PHPExcel_Style();
     $estiloInformacion->applyFromArray( array(
      'font' => array(
     'name'  => 'Arial',
     'size' => 15,
     'color' => array(
     'rgb' => '000000'
     )
      ),
      'fill' => array(
     'type'  => PHPExcel_Style_Fill::FILL_SOLID
     ),
      'borders' => array(
     'allborders' => array(
     'style' => PHPExcel_Style_Border::BORDER_THIN
     )
      ),
     'alignment' =>  array(
     'horizontal'=> PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
     'vertical'  => PHPExcel_Style_Alignment::VERTICAL_CENTER
      )
     ));
   //------------- Definimos como se imprimiran las columnas con sus determinados tamaños -------------------------------------!>  
   $objPHPExcel->getActiveSheet()->getStyle('A1:F4')->applyFromArray($estiloTituloReporte);
   $objPHPExcel->getActiveSheet()->getStyle('A6:F6')->applyFromArray($estiloTituloColumnas);
   $objPHPExcel->getActiveSheet()->mergeCells('C3:F3');
   $objPHPExcel->getActiveSheet()->setCellValue('C3', 'REPORTE MENSUAL DE PIZZANSWER');
   $objPHPExcel ->getProperties()->setCreator("PizzaAnswer")-> setDescription("Reporte Mensual");
   $objPHPExcel->getActiveSheet()->setTitle("Mes - Junio");
	$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
   $objPHPExcel->getActiveSheet()->setCellValue('A6','NumEncuesta');
   $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(60);
   $objPHPExcel->getActiveSheet()->setCellValue('B6','Areas');
   $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(50);
   $objPHPExcel->getActiveSheet()->setCellValue('C6','Respuesta');
   $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(50);
   $objPHPExcel->getActiveSheet()->setCellValue('D6','NombreCliente');
   $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
   $objPHPExcel->getActiveSheet()->setCellValue('E6','Telefono');
   $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
   $objPHPExcel->getActiveSheet()->setCellValue('F6','FechaEncuesta');
   //------------- Hacemos un ciclo para traer los datos de la consulta-------------------------------------!>
   while($row = mysqli_fetch_array($resultado, MYSQLI_ASSOC)){
       $objPHPExcel->getActiveSheet()->setCellValue('A'.$fila,$row['NumEncuesta']);
       $objPHPExcel->getActiveSheet()->setCellValue('B'.$fila,$row['Areas']);
       $objPHPExcel->getActiveSheet()->setCellValue('C'.$fila,$row['Respuesta']);
       $objPHPExcel->getActiveSheet()->setCellValue('D'.$fila,$row['NombreCliente']);
       $objPHPExcel->getActiveSheet()->setCellValue('E'.$fila,$row['Telefono']);
       $objPHPExcel->getActiveSheet()->setCellValue('F'.$fila,$row['FechaEncuesta']);
       $fila++; //Incrementamos las filas
   }
   $fila = $fila-1; // La fila incrementa menos 1
	$objPHPExcel->getActiveSheet()->setSharedStyle($estiloInformacion, "A7:F".$fila);
	$filaGrafica = $fila+2;
   //------------- Realizamos el encabezado y le colocamos el nombre del reporte de excel -------------------------------------!>
   header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
   header('Content-Disposition: attachment; filename="ReportePizzAnswer.xlsx"');
   header('Cache-Control: max-age=0');
   $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
   $objWriter->save('php://output');
?>