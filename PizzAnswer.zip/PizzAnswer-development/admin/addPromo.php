/**
*
* PHP: addPromo.php
* BASE DE DATOS: PizzAnswer -> promocion
* VERSION: 1.0
* DESCRIPCION: Este codigo contiene lo necesario para agregar una promocion.
*
*/

<?php
// Conexion a nuestra BD
include_once '..\conexion.php';

/**
   * SQL a ejecutar
   * @access public
   * @var object
*/
$sql_leer = 'SELECT * FROM promocion';
/**
    * SQL necesario para preparar nuestra sentencia SQL
    * @access public
    * @var object
*/
$gsent = $pdo->prepare($sql_leer);
/**
   * Array de tipo string que nos otorgará todos los registros que la consulta generó
   * @access public
   * @var object
*/
$gsent->execute();
$resultado = $gsent->fetchAll();

/**
 * Este if será llamado solo cuando se haya presionado al botón de "aceptar", lo que hará será ejecutar las indicaciones que se le indican.
*/
if($_POST){
    /** 
            *   Declaración de variables y su tipo de dato
            *
            *   @access public
            *   @var $imagen string
    */
    $imagen='';
    // If que se llama cuando se añadi un archivo
    if(isset($_FILES["archivo"])){
        /** 
            *   Declaración de variables y su tipo de dato
            *
            *   @access public
            *   @var $file object
            *   @var $nombreimg string
            *   @var $tipo string
            *   @var $ruta_provisional string
            *   @var $size int
            *   @var $dimensiones int
            *   @var $width int
            *   @var $height int
            *   @var $carpeta string
        */
        $file = $_FILES["archivo"];
        $nombreimg = $file["name"];
        $tipo = $file["type"];
        $ruta_provisional = $file["tmp_name"];
        $size = $file["size"];
        $dimensiones = getimagesize($ruta_provisional);
        $width = $dimensiones[0];
        $height = $dimensiones[1];
        $carpeta = "../promos/";
        // If utilizado para determinar el formato del archivo
        if($tipo != 'image/jpg' && $tipo != 'image/JPG' && $tipo != 'image/jpeg' && $tipo != 'image/png' && $tipo != 'image/gif'){
            echo "Error, el archivo no es una imagen.";
        // else para determinar el limite de tamaño
        } elseif ($size > 3*1024*1024) {
            echo "Error, el tamaño maximo permitido es un 3MB.";
        // else para guardar la ruta del archivo
        } else {
            $src = $carpeta.$nombreimg;
            move_uploaded_file($ruta_provisional, $src);
            $imagen=$nombreimg;
        }
    }

    /** 
            *   Declaración de variables y su tipo de dato
            *
            *   @access public
            *   @var $nombre string
            *   @var $inicio date
            *   @var $vigencia date
        */
    $nombre = $_POST['nombre'];
    $inicio = $_POST['inicio'];
    $vigencia = $_POST['vigencia'];
    /**
   * SQL a ejecutar
   * @access public
   * @var object
   */
    $sql_agregar = 'INSERT INTO promocion (imagen, iniPromo, vigenciaPromo, nombrePromo) VALUES (?, ?, ?, ?)';
    /**
     * SQL necesario para preparar nuestra sentencia SQL
     * @access public
     * @var object
     */
    $sentencia_agregar = $pdo->prepare($sql_agregar);
    /**
     * SQL necesario para ejecutar una insercion
     * @access public
     */
    $sentencia_agregar->execute(array($imagen, $inicio, $vigencia, $nombre));
}
?>

<!-- Creacion de nuestro HTML -->
<html lang="es">
<head>
    <!-- Las siguientes instrucciones garantiza la compatibilidad entre navegadores -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- La siguiente instruccion es la hoja de estilos del header -->
    <link rel='stylesheet' type="text/css" href="../estiloa.css">
    <!-- La siguiente instruccion es la hora de estilos de la interfaz -->
    <link rel='stylesheet' type="text/css" href="addPromoR.css">
</head>
    <!-- La siguiente instruccion es el nombre de nuestra pestaña -->
    <title>Gerencia | Agregar promoción</title>
<body>
    <header>
        <nav class = "menuPizza">
            <!-- La siguiente instruccion obtiene el logo de nuestro header desde la carpeta images -->
            <img src="../images/logoNegro.PNG" class="logoP">
            <!-- La siguiente instruccion es el titulo del header -->
            <label class="logoPizza">PizzAnswer/Gerencia</label>
            <!-- La siguiente instruccion sirve para realizar los elementos del header -->
            <ul class="menupizza_item">
                <!-- El siguiente elemento sirve para redirigirse a la interfaz principalGerencia.php -->
                <li><a href="principalGerencia.php">Inicio</a></li>
                <!-- El siguiente elemento sirve para redirigirse a la interfaz verPromo.php -->
                <li><a href="verPromo.php">Promociones</a></li>
                <!-- El siguiente elemento sirve para redirigirse a la interfaz verEncuesta.php -->
                <li><a href="verEncuesta.php">Encuesta</a></li>
            </ul>
        </nav>
    </header>
    <!-- En la siguiente instruccion tenemos nuestro titulo de la interfaz -->
    <p class="pt1">Agregar Promoción</p>
    <!-- En la siguiente instruccion tenemos una clase contenedor la cual es utilizada para mover el formulario completo -->
    <div class="contenedor">
        <!-- En la siguiente instruccion tenemos una clase form la cual incluira todos nuestros componentes del formulario -->
        <div class="form">
            <!-- La siguiente instruccion sirve para indicar que vamos a crear un formulario y prepararlo para enviar los datos -->
            <form action="#" method="POST" enctype="multipart/form-data">
                <!-- La siguiente instruccion sirve para agregar un campo de texto el cual sirve para indicar el nombre de la promocion -->
                <p class="textos">Nombre:<input type="text" name="nombre"  class="elementos" placeholder="Escriba un nombre..." required></p>
                <br>
                <br>
                <br>
                <!-- La siguiente instruccion sirve para agregar un calendario el cual sirve para indicar la fecha de inicio -->
                <p class="textos">Inicio:<input type="date" name="inicio"  class="elementos" required></p>
                <br>
                <br>
                <br>
                <!-- La siguiente instruccion sirve para agregar un calendario el cual sirve para indicar la fecha de finalizacion -->
                <p class="textos">Vigencia:<input type="date" name="vigencia"  class="elementos" required></p>
                <br>
                <br>
                <br>
                <!-- La siguiente instruccion sirve para agregar un boton el cual sirve para seleccionar una archivo -->
                <p class="textos">Imagen Promo:</p>
                <div id="div_file">
                    <p id="texto">Seleccionar archivo...</p>
                    <input type="file" name="archivo" id="btn_enviar"  class="elementos" required>
                </div>
                <br>
                <br>
                <!-- La siguiente instruccion sirve para agregar un boton el cual funcionara para enviar los datos a la BD -->
                <input type="submit" name="btnAceptar" class="boton1" value="Aceptar">
            </form>
            <!-- La siguiente instruccion sirve para agregar un boton el cual redirigira a la interfaz verPromo.php -->
            <a href="verPromo.php"><button type="submit" id="btn_regresar" class="boton2">Regresar</button></a>
        </div>
    </div>
</body>
</html