/**
*
* PHP: addCupon.php
* BASE DE DATOS: PizzAnswer -> cupon
* VERSION: 1.0
* DESCRIPCION: Este codigo contiene lo necesario para agregar un cupon.
*
*/

<?php
// Conexion a nuestra BD
include_once '..\conexion.php';

/**
   * SQL a ejecutar
   * @access public
   * @var object
*/
$sql_leer = 'SELECT * FROM cupon';
/**
    * SQL necesario para preparar nuestra sentencia SQL
    * @access public
    * @var object
*/
$gsent = $pdo->prepare($sql_leer);
/**
   * Array de tipo string que nos otorgará todos los registros que la consulta generó
   * @access public
   * @var object
*/
$gsent->execute();
$resultado = $gsent->fetchAll();

// Funcion para generar folios mediante el recibimiento de un parametro
function generacupon($n){
    // Cadena de caracteres que utilizaran los folios
    $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    // Divisor de caracteres
    $randomcadena = '';
  
    // Ciclo para indicar el numero de caracteres que llevaran los folios
    for ($i = 0; $i < $n; $i++) {
        // Funcion aleatoria para seleccionar un caracter de la cadena de caracteres
        $index = rand(0, strlen($caracteres) - 1);
        // Concatenacion de los caracteres
        $randomcadena .= $caracteres[$index];
    }
    
    // Retorno del resultado
    return $randomcadena;
    
}

/**
 * Este if será llamado solo cuando se haya presionado al botón de "aceptar", lo que hará será ejecutar las indicaciones que se le indican.
*/

if($_POST){
    /** 
            *   Declaración de variables y su tipo de dato
            *
            *   @access public
            *   @var $tfolios int
            *   @var $canjeado int
            *   @var $nombre string
            *   @var $descripcion string
            *   @var $nocupones int
            *   @var $vigencia date
            *
    */
    $tfolios = 6;
    $canjeado = 0;
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $nocupones = $_POST['nocupones'];
    $vigencia = $_POST['vigencia'];
    /**
   * SQL a ejecutar
   * @access public
   * @var object
   */
    $sql_agregar = 'INSERT INTO cupon (nombreCupon, descripcionCupon, numCupones, vigenciaCupon) VALUES (?, ?, ?, ?)';
    /**
     * SQL necesario para preparar nuestra sentencia SQL
     * @access public
     * @var object
     */
    $sentencia_agregar = $pdo->prepare($sql_agregar);
    /**
     * SQL necesario para ejecutar una insercion
     * @access public
     */
    $sentencia_agregar->execute(array($nombre, $descripcion, $nocupones, $vigencia));

    /**
   * SQL a ejecutar
   * @access public
   * @var object
   */
    $sql_consultarid = 'SELECT MAX(idCupon) as "idCupon" FROM cupon';
    /**
   * Resultado de la ejecución del sql anterior, esta variable guardará todos los registros que nos regresó la BD
   * @access public
   * @var object
   */
    $gsent = $pdo->prepare($sql_consultarid);
    $gsent->execute();
    /**
   * Array de tipo string que nos otorgará todos los registros que la consulta generó
   * @access public
   * @var object
   */
    $idPadre = $gsent->fetchAll();
    $idSub = $idPadre[0];

    // Ciclo for que se detiene hasta que se ha llegado al numero de cupones que se han determinado
    for ($i = 0; $i < $nocupones; $i++) {
        // Preparacion de la sentencia SQL para insertar los folios
        $sql_agregarfolio = 'INSERT INTO folioscupon (folioCupon, idCupon, canjeado) VALUES (?, ?, ?)';
        echo $sql_consultarid;
        // Sentencia SQL preparada para ejecutarse usando el pdo
        $sentencia_agregarfolio = $pdo->prepare($sql_agregarfolio);
        // Sentencia SQL de la ejecucion para insertar los valores de las variables
        // Llamado a la funcion generacupon para determinar los folios
        $sentencia_agregarfolio->execute(array(generacupon($tfolios), $idSub['idCupon'], $canjeado));
    }

}
?>

<!-- Creacion de nuestro HTML -->
<html lang="es">
<head>
    <!-- Las siguientes instrucciones garantiza la compatibilidad entre navegadores -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- La siguiente instruccion es la hoja de estilos del header -->
    <link rel='stylesheet' type="text/css" href="../estiloa.css">
    <!-- La siguiente instruccion es la hora de estilos de la interfaz -->
    <link rel='stylesheet' type="text/css" href="addCuponR.css">
</head>
    <!-- La siguiente instruccion es el nombre de nuestra pestaña -->
    <title>Gerencia | Agregar cupon</title>
<body>
    <header>
        <nav class = "menuPizza">
            <!-- La siguiente instruccion obtiene el logo de nuestro header desde la carpeta images -->
            <img src="../images/logoNegro.PNG" class="logoP">
            <!-- La siguiente instruccion es el titulo del header -->
            <label class="logoPizza">PizzAnswer/Gerencia</label>
            <!-- La siguiente instruccion sirve para realizar los elementos del header -->
            <ul class="menupizza_item">
                <!-- El siguiente elemento sirve para redirigirse a la interfaz principalGerencia.php -->
                <li><a href="principalGerencia.php">Inicio</a></li>
                <!-- El siguiente elemento sirve para redirigirse a la interfaz verPromo.php -->
                <li><a href="verPromo.php">Promociones</a></li>
                <!-- El siguiente elemento sirve para redirigirse a la interfaz verEncuesta.php -->
                <li><a href="verEncuesta.php">Encuesta</a></li>
            </ul>
        </nav>
    </header>
    <!-- En la siguiente instruccion tenemos nuestro titulo de la interfaz -->
    <p class="pt1">Agregar Cupón</p>
    <!-- En la siguiente instruccion tenemos una clase contenedor la cual es utilizada para mover el formulario completo -->
    <div class="contenedor">
            <!-- En la siguiente instruccion tenemos una clase form la cual incluira todos nuestros componentes del formulario -->
            <div class="form">
                <!-- La siguiente instruccion sirve para indicar que vamos a crear un formulario y prepararlo para enviar los datos -->
                <form action="#" method="POST">
                    <!-- La siguiente instruccion sirve para agregar un cammpo de texto el cual sirve para indicar el nombre del cupon -->
                    <p class="textos">Nombre:<input type="text" name="nombre" class="elementos" placeholder="Escriba el nombre aquí..." required></p>
                    <br>
                    <br>
                    <br>
                    <!-- La siguiente instruccion sirve para agregar un campo de texto el cual sirve para indicar la descripcion del cupon -->
                    <p class="textos">Descripción:<input type="text" name="descripcion" class="elementos" placeholder="Escriba la descripción aquí..." required></p>
                    <br>
                    <br>
                    <br>
                    <!-- La siguiente instruccion sirve para agregar un campo de texto el cual sirve para indicar el numero de cupones -->
                    <p class="textos">No. Cupones:<input type="text" name="nocupones" class="elementos" placeholder="Escriba el numero de cupones aquí..." required></p>
                    <br>
                    <br>
                    <br>
                    <!-- La siguiente instruccion sirve para agregar un elemento de tipo fecha el cual servira para elegir la vigencia -->
                    <p class="textos">Vigencia:<input type="date" name="vigencia" class="elementos" required></p>
                    <br>
                    <br>
                    <br>
                    <!-- La siguiente instruccion sirve para agregar un boton el cual funcionara para enviar los datos a la BD -->
                    <input type="submit" name="btnAceptar" class="boton1" value="Aceptar">
                </form>
                <!-- La siguiente instruccion sirve para agregar un boton el cual redirigira a la interfaz cuponAdmin.php -->
                <a href="cuponAdmin.php"><button type="submit" id="btn_regresar" class="boton2">Regresar</button></a>
            </div>
        </div>
</body>
</html