<?php
include_once '..\conexion.php';
session_start();

// if (!isset($_SESSION['user_id'])) {
//     header('Location: index.php');
//     exit;
// } else {
//     // Show users the page!
// }


?>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link type="text/css" href="bootstrap.min.css" rel="stylesheet">
    <link rel='stylesheet' type="text/css" href="../estiloa.css">
    <link rel='stylesheet' type="text/css" href="verCupon.css">
    <title>Eliminar Promociones</title>
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <header>
        <nav class="menuPizza">
            <img src="../images/logoNegro.PNG" class="logoP">
            <label class="logoPizza">PizzAnswer/Gerencia</label>
            <ul class="menupizza_item">
                <li><a href="principalGerencia.php">Inicio</a></li>
                <li><a href="verPromo.php">Promociones</a></li>
                <li><a href="#">Encuesta</a></li>
            </ul>
        </nav>
    </header>
    <div class="titulo">
        Cupones
    </div>
    <div class="main-wrapper">
        <br><br>
        <?php
        include("delete/function.php");
        ?>
        <table border="1" width="50%">
            <tr>
                <th width="27%">Nombre Cupon</th>
                <th width="45%">Descripcion</th>
                <th width="15%">Folios generados</th>
                <th width="12%">Vigencia</th>
            </tr>
            <?php
            $sql = "select * from cupon";
            $result = db_query($sql);
            while ($row = mysqli_fetch_object($result)) {
            ?>
                <tr>
                    <td><?php echo $row->nombreCupon; ?></td>
                    <td><?php echo UTF8_ENCODE($row->descripcionCupon); ?></td>
                    <td><?php echo $row->numCupones; ?></td>
                    <td><?php echo $row->vigenciaCupon; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>

    <div class="titulo">
        Folios Restantes
    </div>
    <div class="main-wrapper">
        <br><br>
        
        <table border="1" width="50%">
            <tr>
                <th width="60%">Nombre Cupon</th>
                <th width="40%">Folio</th>
            </tr>
            <?php
            $sql2 = "select c.nombreCupon as 'nombreCupon', fc.folioCupon as 'folio' from folioscupon fc inner join cupon c on (c.idCupon = fc.idCupon) where fc.canjeado = 0";
            $result2 = db_query($sql2);
            while ($row2 = mysqli_fetch_object($result2)) {
            ?>
                <tr>
                    <td><?php echo $row2->nombreCupon; ?></td>
                    <td><?php echo $row2->folio; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <div class="contenedorbotones">
        <a href="cuponAdmin.php"><button type="#" class="botones">Regresar</button></a>
    </div>


</body>

</html>