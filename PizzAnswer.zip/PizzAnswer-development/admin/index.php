<?php

/**
 *
 * PHP Relacionados: conexion.php
 * BASE DE DATOS: PizzAnswer -> Gerente
 * VERSION: 1.0
 * DESCRIPCION: Este archivo mostrará la pagina de contacto de la pizzeria, pagina en la cual se verá toda la información para ubicar
 * a las mismas así como su telefono, nombre y un mapa interactivo
 *
 */

include_once '..\conexion.php';
session_start();

/**
 * Este if sirve para ejecutarse cuando el usuario haga click en el botón de iniciar sesión, servirá para validar las credenciales
 * y así aumentar la seguridad del sistema
 */
if (isset($_POST['login'])) {

    /**
     * Nombre de usuario ingresado
     * @access public
     * @var string
     */
    $username = $_POST['username'];
    
    /**
     * Contraseña ingresada
     * @access public
     * @var string
     */
    $password = $_POST['password'];
    
    /**
     * SQL a ejecutar para autentificar al usuario gerente en el sistema
     * @access public
     * @var object
     */
    $query = $pdo->prepare("SELECT * FROM gerente WHERE usuario=:username");
    $query->bindParam("username", $username, PDO::PARAM_STR);
    $query->execute();

    /**
     * Resultado de la consulta anterior, en caso de ser false/null significa que la combinación de usuario y contraseña no existen
     * @access public
     * @var mixed
     */
    $result = $query->fetch(PDO::FETCH_ASSOC);
    
    /**
     * If para comprobar que el registro existe y así poder dejar al gerente iniciar sesión dentro de nuestro sistema
     */
    if (!$result) {
        echo "<script>
                alert('¡Nombre de usuario no existe!');
                window.location= 'index.php'
        </script>";
    } else {
        /**
         * If necesario para verificar que la clave ingresada es correcta y está asociada a un usuario especifico
         */
        if ( $result['claveGerente'] ==  $password) {
            $_SESSION['user_id'] = $result['ID'];
            header('location: principalGerencia.php');
        } else {
            echo "<script>
                alert('¡Contraseña incorrecta!');
                window.location= 'index.php'
        </script>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel='stylesheet' type="text/css" href="../estiloa.css">
    <title>Login Gerente</title>
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <header>
        <nav class="menuPizza">
            <img src="../images/logoGer.PNG" class="logoP">
            <label class="logoPizza">PizzAnswer/Gerencia</label>
        </nav>
    </header>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <!-- Formulario para que el gerente pueda iniciar sesión dentro de nuestro sistema   -->
                <form method="POST" action="" name="signin-form">
                    <br><br><br><br><br><br>
                    <h1>Usuario:</h1>
                    <br>
                    <input type="text" class="form-control" name="username" pattern="[a-zA-Z0-9]+" placeholder="Ingresa tu usuario" required><br>
                    <h1>Clave:</h1>
                    <br>
                    <input type="password" class="form-control" name="password" placeholder="Ingresa tu contraseña" required>
                    <button class="btn btn-light mt-5" type="submit" name="login" value="login"> Iniciar sesión </button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>