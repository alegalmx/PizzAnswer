<?php
/**
* 
* PHP Relacionados: conexion.php
* BASE DE DATOS: PizzAnswer -> cupon, foliosCupon
* VERSION: 1.0
* DESCRIPCION: Este archivo mostrará la pagina de cupon para el administrador, en ella el mismo podrá canjear un folio
* para hacer valido el canje de una promocion dada al cliente después de contestar la encuesta
*
*/

include_once '../conexion.php';
/**
 * Este if será llamado solo cuando se haya presionado al botón de "canjear", lo que hará será mostrar la información de dicho cupón y
 * además va a marcarlo como entragado en la BDD
 */
if ($_POST) {
  /**
   * Variable que regresa el conjunto de caracteres ingresados en el campo de "folio ingresado"
   * @access public
   * @var array
   */
  $folioIngresado = $_POST['folioIngresado'];

  /**
   * SQL a ejecutar
   * @access public
   * @var string
   */
  $sql_leer = 'SELECT c.folioCupon, cc.nombreCupon as "nombre", cc.descripcionCupon as "descripcion", cc.vigenciaCupon FROM folioscupon c INNER JOIN cupon cc on c.idCupon = cc.idCupon WHERE c.canjeado = 0 and c.folioCupon =:folioIngresado';
  
  /**
   * Resultado de la ejecución del sql anterior, esta variable guardará todos los registros que nos regresó la BDD
   * @access public
   * @var object
   */
  $gsent = $pdo->prepare($sql_leer);
  $gsent->bindParam("folioIngresado", $folioIngresado, PDO::PARAM_STR);
  $gsent->execute();

  /**
   * Array de tipo string que nos otorgará todos los registros que la consulta generó
   * @access public
   * @var object
   */
  $resultado = $gsent->fetchAll();
  
  /**
   * En caso de que el SQL haya regresado algo se va a ejecutar el else, caso contrario nos dirá que el folio ya fue ingresado
   */
  if (!$resultado) {
    echo "<script>
                alert('El cupón con folio " . $folioIngresado . " ya ha sido canjeado!');
                window.location= 'cuponAdmin.php'
    </script>";
  } else {
    /**
     * Array de tipo string que nos otorgará una sola fila del resultado que nos dió el SQL ejecutado
     * @access public
     * @var mixed
     */
    $cupon = $resultado[0];
    
    /**
     * SQL necesario para ejecutar un update
     * @access public
     * @var string
     */
    $sql_canjear = 'UPDATE folioscupon set canjeado = 1 where folioCupon =:folioIngresado';
    $sentencia_agregar = $pdo->prepare($sql_canjear);
    $sentencia_agregar->bindParam("folioIngresado", $folioIngresado, PDO::PARAM_STR);
    $sentencia_agregar->execute();
    echo "<script>
                alert('Folio: " . $folioIngresado . ", " . $cupon['descripcion'] . " ha sido canjeado');
                window.location= 'cuponAdmin.php'
    </script>";
    
  }
}
?>

<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel='stylesheet' type="text/css" href="../estiloa.css">
  <link rel='stylesheet' type="text/css" href="canjearCupon.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.css" />
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.js"></script>
  <title>Gerente/Cupón</title>
</head>

<body>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
  <header>
    <nav class="menuPizza">
      <img src="../images/logoNegro.PNG" class="logoP">
      <label class="logoPizza">PizzAnswer/Gerencia</label>
      <ul class="menupizza_item">
        <li><a href="principalGerencia.php">Inicio</a></li>
        <li><a href="verPromo.php">Promociones</a></li>
        <li><a href="verEncuesta.php">Encuesta</a></li>
      </ul>
    </nav>
  </header>
  
  <h1 class="tituloC">Cupones</h1>

  <!--  Formulario para introducir el Folio del cupón que se desea canjear-->
  <form class="cupon" method="POST">
    <input type="text" name="folioIngresado" placeholder="Ingrese cupón aqui..." required>
    <button type="#" name="canjearC" class="canjear">Canjear</button>
  </form>

  <a href="principalGerencia.php"><button type="#" class="back">Regresar</button></a>
  <a href="addCupon.php"><button type="#" class="add">Agregar cupón</button></a>
  <a href="verCupon.php"><button type="#" class="see">Ver Cupones</button></a>
</body>

</html>