<?php
/*
//NO MOVER
$link = 'mysql:host=sql3.freesqldatabase.com:3306/; dbname=sql3418606; charset=utf8';
$usuario = 'sql3418606';
$pass = 'FcqWkvTndP';

//CORREO Y PASS SQL
//zgnkyeqphhjrffafmx@niwghx.com
//PizzAnswer123

try {
    $pdo = new PDO($link, $usuario, $pass);

    //echo 'Conectado';
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br\>";
    die();
}*/

//Para que funcione en el webhost

$servername = "sql3.freesqldatabase.com:3306/";
$username = "sql3418606";
$password = "FcqWkvTndP";
$database = "sql3418606";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    } catch(PDOException $e) {    
    echo "Connection failed: " . $e->getMessage();
    die();
}

?>
